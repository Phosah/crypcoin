<section class="py-16 md:py-28">
    <div class="flex items-center justify-center space-x-6 md:space-x-12 wow animate__slideInLeft" data-wow-duration="1.5s">
        <div class="flex-1 ">
            <img class="" src="img/ethereum.png" alt="ethereum photo">
        </div>
        <div class="flex-1">
            <img class="" src="img/bitcoincash.png" alt="bitcoincash photo">
        </div>
        <div class="hidden lg:block flex-1">
            <img class="" src="img/payeer.png" alt="payeer photo">
        </div>
        <div class="flex-1">
            <img class="" src="img/litecoin.png" alt="litecoin photo">
        </div>
        <div class="flex-1">
            <img class="" src="img/bitcoin.png" alt="Bitcoin photo">
        </div>            
        <div class="hidden lg:block flex-1">
            <img class="" src="img/perfect.png" alt="Perfect photo">
        </div>            
    </div>
</section>